Run with:
```sh
docker run -d -p 8080:8080 -p 50000:50000 -v /your/home:/var/jenkins_home -v /var/lib/docker.sock:/var/lib/docker.sock yourjenkins
```
